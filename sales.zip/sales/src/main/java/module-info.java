module com.example.sales {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.sql;


    opens com.example.sales to javafx.fxml;
    exports com.example.sales;
}