package com.example.sales;
import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.chart.BarChart;
import javafx.scene.chart.CategoryAxis;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.XYChart;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.Image;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.CornerRadii;
import javafx.scene.layout.HBox;
import javafx.scene.layout.StackPane;
import javafx.scene.paint.Color;
import javafx.stage.Stage;

import java.io.File;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class HelloApplication extends Application {

 private static final String DB_HOST = "localhost";
 private static final int DB_PORT = 3306;
 private static final String DB_NAME = "new_schema";
 private static final String DB_USER = "root";
 private static final String DB_PASSWORD = "root@123";

 private Scene mainScene;
 private Scene tableScene;

 public static void main(String[] args) {
  launch(args);
 }

 @Override
 public void start(Stage primaryStage) {
  primaryStage.setTitle("Database App");

  // Set application icon
  primaryStage.getIcons().add(new Image(new File("image.png").toURI().toString()));


  // Create a button to switch scenes
  Button switchButton = new Button("Switch to Table View");
  switchButton.setOnAction(e -> primaryStage.setScene(tableScene));

  // Create the main scene with a chart
  BarChart<String, Number> barChart = createChart();
  StackPane mainLayout = new StackPane(barChart, switchButton);
  mainLayout.setBackground(new Background(new BackgroundFill(Color.LIGHTBLUE, CornerRadii.EMPTY, Insets.EMPTY)));
  mainScene = new Scene(mainLayout, 800, 600);
  mainScene.getStylesheets().add("styles.css");

  // Create the table scene
  TableView<DataObject> tableView = createTableView();
  StackPane tableLayout = new StackPane(tableView);
  tableLayout.setBackground(new Background(new BackgroundFill(Color.LIGHTGREEN, CornerRadii.EMPTY, Insets.EMPTY)));
  tableScene = new Scene(tableLayout, 800, 600);
  tableScene.getStylesheets().add("styles.css");

  // Connect to the MySQL database and populate the chart and table
  try (Connection connection = DriverManager.getConnection("jdbc:mysql://" + DB_HOST + ":" + DB_PORT + "/" + DB_NAME, DB_USER, DB_PASSWORD);
       Statement statement = connection.createStatement()) {

   // Fetch data for the chart
   ResultSet resultSet = statement.executeQuery("SELECT date, breakfast,lunch,dinner FROM data_table");
   ObservableList<XYChart.Data<String, Number>> chartData = FXCollections.observableArrayList();
   while (resultSet.next()) {
    String item = resultSet.getString("item");
    int breakfast = resultSet.getInt("breakfast");
    int lunch = resultSet.getInt("lunch");
    int dinner = resultSet.getInt("dinner");
    chartData.add(new XYChart.Data<>(item, breakfast));
   }
   XYChart.Series<String, Number> series = new XYChart.Series<>();
   series.setData(chartData);
   barChart.getData().add(series);

   // Fetch data for the table
   resultSet = statement.executeQuery("SELECT * FROM data_table1");
   ObservableList<DataObject> tableData = FXCollections.observableArrayList();
   while (resultSet.next()) {
    String name = resultSet.getString("name");
    int quantity = resultSet.getInt("quantity");
    double price = resultSet.getDouble("price");
    tableData.add(new DataObject(name, quantity, price));
   }
   tableView.setItems(tableData);
  } catch (Exception e) {
   e.printStackTrace();
  }

  // Set the main scene as the initial scene
  primaryStage.setScene(mainScene);
  primaryStage.show();
 }

 private BarChart<String, Number> createChart() {
  CategoryAxis xAxis = new CategoryAxis();
  NumberAxis yAxis = new NumberAxis();
  BarChart<String, Number> chart = new BarChart<>(xAxis, yAxis);
  chart.setTitle("Data Chart");
  return chart;
 }

 private TableView<DataObject> createTableView() {
  TableView<DataObject> tableView = new TableView<>();

  TableColumn<DataObject, String> nameColumn = new TableColumn<>("Name");
  nameColumn.setCellValueFactory(new PropertyValueFactory<>("name"));

  TableColumn<DataObject, Integer> quantityColumn = new TableColumn<>("Quantity");
  quantityColumn.setCellValueFactory(new PropertyValueFactory<>("quantity"));

  TableColumn<DataObject, Double> priceColumn = new TableColumn<>("Price");
  priceColumn.setCellValueFactory(new PropertyValueFactory<>("price"));

  tableView.getColumns().addAll(nameColumn, quantityColumn, priceColumn);

  return tableView;
 }

 public static class DataObject {
  private String name;
  private int quantity;
  private double price;

  public DataObject(String name, int quantity, double price) {
   this.name = name;
   this.quantity = quantity;
   this.price = price;
  }

  public String getName() {
   return name;
  }

  public int getQuantity() {
   return quantity;
  }

  public double getPrice() {
   return price;
  }
 }
}
